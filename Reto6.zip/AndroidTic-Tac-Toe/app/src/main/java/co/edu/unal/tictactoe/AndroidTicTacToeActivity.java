package co.edu.unal.tictactoe;

import android.media.MediaPlayer;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import android.view.*;
import android.widget.*;
import android.graphics.*;
import android.app.*;
import android.content.*;

public class AndroidTicTacToeActivity extends AppCompatActivity {

    static final int DIALOG_DIFFICULTY_ID = 0;
    static final int DIALOG_SOUND_ID = 5;
    static final int DIALOG_ABOUT_ID = 10;
    static final int DIALOG_RESET_SCORES_ID = 20;

    // Represents the internal state of the game
    private TicTacToeGame mGame;

    // A board's view
    private BoardView mBoardView;
    // Sound
    MediaPlayer mHumanMediaPlayer;
    MediaPlayer mComputerMediaPlayer;
    MediaPlayer mWinMediaPlayer;

    // Who's turn
    private char mTurn;
    // SoundTurnOn
    private boolean mSoundTurnOn = true;

    // Various text displayed
    private TextView mInfoTextView;
    private TextView mHuman;
    private TextView mAndroid;
    private TextView mTie;
    // Game finished
    private boolean mGameOver;
    // Register
    private int mHumanWonCount;
    private int mAndroidWonCount;
    private int mTieCount;
    private int mNumberGame;

    private SharedPreferences mPrefs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_android_tic_tac_toe);

        //Amount of games played
        mNumberGame = 1;

        mGame = new TicTacToeGame();
        mBoardView = (BoardView) findViewById(R.id.board);
        mBoardView.setGame(mGame);
        // Listen for touches on the board
        mBoardView.setOnTouchListener(mTouchListener);

        // Save when back button is oppressed
        mPrefs = getSharedPreferences("ttt_prefs", MODE_PRIVATE);

        String difficultyLevel = mPrefs.getString("difficulty_level", getResources().getString(R.string.difficulty_expert));
        if (difficultyLevel.equals(getResources().getString(R.string.difficulty_easy))) {
            mGame.setDifficultyLevel(TicTacToeGame.DifficultyLevel.Easy);
        }else if (difficultyLevel.equals(getResources().getString(R.string.difficulty_harder))) {
            mGame.setDifficultyLevel(TicTacToeGame.DifficultyLevel.Harder);
        }else {
            mGame.setDifficultyLevel(TicTacToeGame.DifficultyLevel.Expert);
        }
        // Restore the scores
        // Second parameter is 0 if mPrefs is not called
        mHumanWonCount = mPrefs.getInt("mHumanWonCount", 0);
        mAndroidWonCount = mPrefs.getInt("mAndroidWonCount", 0);
        mTieCount = mPrefs.getInt("mTieCount", 0);

        mInfoTextView = (TextView) findViewById(R.id.information);

        mHuman = (TextView) findViewById(R.id.human_results);
        mAndroid = (TextView) findViewById(R.id.android_results);
        mTie = (TextView) findViewById(R.id.tie_results);

        if (savedInstanceState == null) {
            startNewGame();
        }
        else {
            // Restore the game's state
            mGame.setBoardState(savedInstanceState.getCharArray("board"));
            mGameOver = savedInstanceState.getBoolean("mGameOver");
            mInfoTextView.setText(savedInstanceState.getCharSequence("info"));
            mHumanWonCount = savedInstanceState.getInt("mHumanWonCount");
            mAndroidWonCount = savedInstanceState.getInt("mAndroidWonCount");
            mTieCount = savedInstanceState.getInt("mTieCount");
            mNumberGame = savedInstanceState.getInt("mNumberGame");
            mTurn = savedInstanceState.getChar("mTurn");
            mInfoTextView.setTextColor(savedInstanceState.getInt("mInfoTextView"));

            // could not
            if (!mGameOver && mTurn == TicTacToeGame.COMPUTER_PLAYER) {
                mTurn = TicTacToeGame.HUMAN_PLAYER;
                if(mNumberGame % 2 == 0) mNumberGame++;
            }
        }

        setResults();
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);

        outState.putCharArray("board", mGame.getBoardState());
        outState.putBoolean("mGameOver", mGameOver);
        outState.putCharSequence("info", mInfoTextView.getText());
        outState.putInt("mHumanWonCount", Integer.valueOf(mHumanWonCount));
        outState.putInt("mAndroidWonCount", Integer.valueOf(mAndroidWonCount));
        outState.putInt("mTieCount", Integer.valueOf(mTieCount));
        outState.putInt("mNumberGame", mNumberGame);
        outState.putChar("mTurn", mTurn);
        outState.putInt("mInfoTextView", mInfoTextView.getCurrentTextColor());
    }

    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);

        mGame.setBoardState(savedInstanceState.getCharArray("board"));
        mGameOver = savedInstanceState.getBoolean("mGameOver");
        mInfoTextView.setText(savedInstanceState.getCharSequence("info"));
        mHumanWonCount = savedInstanceState.getInt("mHumanWonCount");
        mAndroidWonCount = savedInstanceState.getInt("mAndroidWonCount");
        mTieCount = savedInstanceState.getInt("mTieCount");
        mNumberGame = savedInstanceState.getInt("mNumberGame");
        mTurn = savedInstanceState.getChar("mTurn");
        mInfoTextView.setTextColor(savedInstanceState.getInt("mInfoTextView"));

        // could not
        if (!mGameOver && mTurn == TicTacToeGame.COMPUTER_PLAYER) {
            mTurn = TicTacToeGame.HUMAN_PLAYER;
            if(mNumberGame % 2 == 0) mNumberGame++;
        }

    }

    @Override
    protected void onStop() {
        super.onStop();

        // Save the current scores
        SharedPreferences.Editor ed = mPrefs.edit();
        ed.putInt("mHumanWonCount", mHumanWonCount);
        ed.putInt("mAndroidWonCount", mAndroidWonCount);
        ed.putInt("mTieCount", mTieCount);

        if (mGame.getDifficultyLevel().ordinal() == 0) {
            ed.putString("difficulty_level", getResources().getString(R.string.difficulty_easy) );
        }else if (mGame.getDifficultyLevel().ordinal() == 1) {
            ed.putString("difficulty_level", getResources().getString(R.string.difficulty_harder) );
        }else {
            ed.putString("difficulty_level", getResources().getString(R.string.difficulty_expert) );
        }

        ed.commit();
    }

    @Override
    protected void onResume() {
        super.onResume();

        mHumanMediaPlayer = MediaPlayer.create(getApplicationContext(), R.raw.human_sound);
        mComputerMediaPlayer = MediaPlayer.create(getApplicationContext(), R.raw.android_sound);
        mWinMediaPlayer = MediaPlayer.create(getApplicationContext(), R.raw.final_sound);
    }

    @Override
    protected void onPause() {
        super.onPause();

        mHumanMediaPlayer.release();
        mComputerMediaPlayer.release();
        mWinMediaPlayer.release();
    }

    private void setResults(){
        mHuman.setText(getString(R.string.human, mHumanWonCount));
        mTie.setText(getString(R.string.tie, mTieCount));
        mAndroid.setText(getString(R.string.android, mAndroidWonCount));
    }

    // Set up the game board.
    private void startNewGame() {
        mGameOver = false;
        // Put results
        mGame.clearBoard();
        mBoardView.invalidate();   // Redraw the board
        mTurn = TicTacToeGame.HUMAN_PLAYER;

        if(mNumberGame % 2 == 1){
            // Human goes first
            mInfoTextView.setText(R.string.first_human);
            mInfoTextView.setTextColor(Color.WHITE);
        }else{
            // Android goes first
            mInfoTextView.setText(R.string.first_android);
            mInfoTextView.setTextColor(Color.RED);
            setMove(TicTacToeGame.COMPUTER_PLAYER, mGame.getComputerMove());
            if(mSoundTurnOn){
                try{
                    mComputerMediaPlayer.start();
                }catch (Exception e){}
            }
        }
        mNumberGame++;
    } // End of startNewGame

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);

        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.options_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.new_game:
                startNewGame();
                return true;
            case R.id.ai_difficulty:
                showDialog(DIALOG_DIFFICULTY_ID);
                return true;
            case R.id.sound:
                showDialog(DIALOG_SOUND_ID);
                return true;
            case R.id.about:
                showDialog(DIALOG_ABOUT_ID);
                return true;
            case R.id.reset_scores:
                showDialog(DIALOG_RESET_SCORES_ID);
                return true;
        }
        return false;

    }

    @Override
    protected Dialog onCreateDialog(int id) {
        Dialog dialog = null;
        AlertDialog.Builder builder = new AlertDialog.Builder(this);

        switch(id) {
            case DIALOG_DIFFICULTY_ID:

                builder.setTitle(R.string.difficulty_choose);

                final CharSequence[] levels = {
                        getResources().getString(R.string.difficulty_easy),
                        getResources().getString(R.string.difficulty_harder),
                        getResources().getString(R.string.difficulty_expert)};

                // TODO: Set selected, an integer (0 to n-1), for the Difficulty dialog.
                // selected is the radio button that should be selected.
                int selected = mGame.getDifficultyLevel().ordinal();

                builder.setSingleChoiceItems(levels, selected,
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int item) {
                                dialog.dismiss();   // Close dialog

                                // TODO: Set the diff level of mGame based on which item was selected.
                                mGame.setDifficultyLevel(TicTacToeGame.DifficultyLevel.values()[item]);
                                startNewGame();
                                // Display the selected difficulty level
                                Toast.makeText(getApplicationContext(), levels[item],
                                        Toast.LENGTH_SHORT).show();
                            }
                        });
                dialog = builder.create();

                break;

            case DIALOG_SOUND_ID:

                // Create the quit confirmation dialog
                builder.setMessage(R.string.sound_question)
                        .setCancelable(false)
                        .setPositiveButton(R.string.yes, new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                mSoundTurnOn = true;
                            }
                        })
                        .setNegativeButton(R.string.no, new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                mSoundTurnOn = false;
                            }
                        });
                dialog = builder.create();

                break;

            case DIALOG_ABOUT_ID:
                Context context = getApplicationContext();
                LayoutInflater inflater = (LayoutInflater) context.getSystemService(LAYOUT_INFLATER_SERVICE);
                View layout = inflater.inflate(R.layout.about_dialog, null);
                builder.setView(layout);
                builder.setPositiveButton("OK", null);
                dialog = builder.create();

                break;

            case DIALOG_RESET_SCORES_ID:
                // Create the reset confirmation dialog
                builder.setMessage(R.string.reset_scores_question)
                        .setCancelable(false)
                        .setPositiveButton(R.string.yes, new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                mHumanWonCount = 0;
                                mAndroidWonCount = 0;
                                mTieCount = 0;
                                setResults();
                            }
                        })
                        .setNegativeButton(R.string.no, new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {

                            }
                        });
                dialog = builder.create();

                break;
        }

        return dialog;
    }

    private boolean setMove(char player, int location) {

        if(mGame.setMove(player, location)){
            mBoardView.invalidate();   // Redraw the board
            return true;
        }
        return false;
    }

    // Listen for touches on the board
    private View.OnTouchListener mTouchListener = new View.OnTouchListener() {
        public boolean onTouch(View v, MotionEvent event) {

            // Determine which cell was touched
            int col = (int) event.getX() / mBoardView.getBoardCellWidth();
            int row = (int) event.getY() / mBoardView.getBoardCellHeight();
            int pos = row * 3 + col;

            if (mTurn == TicTacToeGame.HUMAN_PLAYER)
            if (!mGameOver && setMove(TicTacToeGame.HUMAN_PLAYER, pos))	{

                changeTurn(); // Change turn to Android

                if(mSoundTurnOn) {
                    try {
                        mHumanMediaPlayer.start();
                    } catch (Exception e) {}
                }

                // If no winner yet, let the computer make a move
                int winner = mGame.checkForWinner();
                if (winner == 0) {
                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        public void run() {

                            setMove(TicTacToeGame.COMPUTER_PLAYER, mGame.getComputerMove());
                            mBoardView.invalidate();   // Redraw the board
                            changeTurn(); // Change turn to Human

                            if(mSoundTurnOn) {
                                try {
                                    mComputerMediaPlayer.start();
                                } catch (Exception e) {}
                            }

                            int winner = mGame.checkForWinner();
                            //if not winner yet
                            if (winner == 0) {
                                //mTurn = TicTacToeGame.HUMAN_PLAYER;
                                mInfoTextView.setText(R.string.empty);
                            }else{
                                endGame(winner);
                            }

                        }
                    }, 800);

                }else{
                    endGame(winner);
                }

            }

            // So we aren't notified of continued events when finger is moved
            return false;
        }
    };

    private void changeTurn(){
        if(mTurn == TicTacToeGame.HUMAN_PLAYER){
            // Human has the current turn so change
            mTurn = TicTacToeGame.COMPUTER_PLAYER;
        }else{
            // Android has the current turn so change
            mTurn = TicTacToeGame.HUMAN_PLAYER;
        }
    }

    private void endGame(int winner) {
        if (winner == 0) {
            mInfoTextView.setText(R.string.empty);
        }else if (winner == 1) {
            mInfoTextView.setText(R.string.result_tie);
            mInfoTextView.setTextColor(Color.rgb(200, 200, 200));
            mTieCount++;
        }else if (winner == 2) {
            mInfoTextView.setText(R.string.result_human_wins);
            mInfoTextView.setTextColor(Color.rgb(250, 250, 250));
            mHumanWonCount++;
            if(mSoundTurnOn) {
                try {
                    mWinMediaPlayer.start();
                } catch (Exception e) {}
            }
        }else {
            mInfoTextView.setText(R.string.result_computer_wins);
            mInfoTextView.setTextColor(Color.rgb(200, 0, 0));
            mAndroidWonCount++;
            if(mSoundTurnOn) {
                try {
                    mWinMediaPlayer.start();
                } catch (Exception e) {}
            }
        }

        mGameOver = true;
        setResults();

    }

}
