package co.edu.unal.tictactoe;

import android.media.MediaPlayer;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import android.view.*;
import android.widget.*;
import android.graphics.*;
import android.app.*;
import android.content.*;

public class AndroidTicTacToeActivity extends AppCompatActivity {

    static final int DIALOG_DIFFICULTY_ID = 0;
    static final int DIALOG_SOUND_ID = 5;
    static final int DIALOG_ABOUT_ID = 10;
    static final int DIALOG_QUIT_ID = 20;

    // Represents the internal state of the game
    private TicTacToeGame mGame;

    // A board's view
    private BoardView mBoardView;
    // Sound
    MediaPlayer mHumanMediaPlayer;
    MediaPlayer mComputerMediaPlayer;
    MediaPlayer mWinMediaPlayer;

    // Who's turn
    private char mTurn;
    // SoundTurnOn
    private boolean mSoundTurnOn = true;

    // Various text displayed
    private TextView mInfoTextView;
    private TextView mHuman;
    private TextView mAndroid;
    private TextView mTie;
    // Game finished
    private boolean mGameOver;
    // Register
    private int humanWonCount;
    private int androidWonCount;
    private int tieCount;
    private int numberGame;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_android_tic_tac_toe);

        humanWonCount = 0;
        androidWonCount = 0;
        tieCount = 0;
        //Amount of games played
        numberGame = 1;

        mGame = new TicTacToeGame();
        mBoardView = (BoardView) findViewById(R.id.board);
        mBoardView.setGame(mGame);
        // Listen for touches on the board
        mBoardView.setOnTouchListener(mTouchListener);

        mInfoTextView = (TextView) findViewById(R.id.information);

        mHuman = (TextView) findViewById(R.id.human_results);
        mAndroid = (TextView) findViewById(R.id.android_results);
        mTie = (TextView) findViewById(R.id.tie_results);

        setResults();
        startNewGame();
    }

    @Override
    protected void onResume() {
        super.onResume();

        mHumanMediaPlayer = MediaPlayer.create(getApplicationContext(), R.raw.human_sound);
        mComputerMediaPlayer = MediaPlayer.create(getApplicationContext(), R.raw.android_sound);
        mWinMediaPlayer = MediaPlayer.create(getApplicationContext(), R.raw.final_sound);
    }

    @Override
    protected void onPause() {
        super.onPause();

        mHumanMediaPlayer.release();
        mComputerMediaPlayer.release();
        mWinMediaPlayer.release();
    }


    // Set up the game board.
    private void startNewGame() {
        mGameOver = false;
        // Put results
        mGame.clearBoard();
        mBoardView.invalidate();   // Redraw the board
        mTurn = TicTacToeGame.HUMAN_PLAYER;

        if(numberGame % 2 == 1){
            // Human goes first
            mInfoTextView.setText(R.string.first_human);
            mInfoTextView.setTextColor(Color.WHITE);
        }else{
            // Android goes first
            mInfoTextView.setText(R.string.first_android);
            mInfoTextView.setTextColor(Color.RED);
            setMove(TicTacToeGame.COMPUTER_PLAYER, mGame.getComputerMove());
            if(mSoundTurnOn){
                try{
                    mComputerMediaPlayer.start();
                }catch (Exception e){}
            }
        }
        numberGame++;
    } // End of startNewGame


    private void setResults(){
        mHuman.setText(getString(R.string.human, humanWonCount));
        mTie.setText(getString(R.string.tie, tieCount));
        mAndroid.setText(getString(R.string.android, androidWonCount));
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);

        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.options_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.new_game:
                startNewGame();
                return true;
            case R.id.ai_difficulty:
                showDialog(DIALOG_DIFFICULTY_ID);
                return true;
            case R.id.sound:
                showDialog(DIALOG_SOUND_ID);
                return true;
            case R.id.about:
                showDialog(DIALOG_ABOUT_ID);
                return true;
            case R.id.quit:
                showDialog(DIALOG_QUIT_ID);
                return true;
        }
        return false;

    }

    @Override
    protected Dialog onCreateDialog(int id) {
        Dialog dialog = null;
        AlertDialog.Builder builder = new AlertDialog.Builder(this);

        switch(id) {
            case DIALOG_DIFFICULTY_ID:

                builder.setTitle(R.string.difficulty_choose);

                final CharSequence[] levels = {
                        getResources().getString(R.string.difficulty_easy),
                        getResources().getString(R.string.difficulty_harder),
                        getResources().getString(R.string.difficulty_expert)};

                // TODO: Set selected, an integer (0 to n-1), for the Difficulty dialog.
                // selected is the radio button that should be selected.
                int selected = mGame.getDifficultyLevel().ordinal();

                builder.setSingleChoiceItems(levels, selected,
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int item) {
                                dialog.dismiss();   // Close dialog

                                // TODO: Set the diff level of mGame based on which item was selected.
                                mGame.setDifficultyLevel(TicTacToeGame.DifficultyLevel.values()[item]);
                                startNewGame();
                                // Display the selected difficulty level
                                Toast.makeText(getApplicationContext(), levels[item],
                                        Toast.LENGTH_SHORT).show();
                            }
                        });
                dialog = builder.create();

                break;

            case DIALOG_SOUND_ID:

                // Create the quit confirmation dialog
                builder.setMessage(R.string.sound_question)
                        .setCancelable(false)
                        .setPositiveButton(R.string.yes, new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                mSoundTurnOn = true;
                            }
                        })
                        .setNegativeButton(R.string.no, new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                mSoundTurnOn = false;
                            }
                        });
                dialog = builder.create();

                break;

            case DIALOG_ABOUT_ID:
                Context context = getApplicationContext();
                LayoutInflater inflater = (LayoutInflater) context.getSystemService(LAYOUT_INFLATER_SERVICE);
                View layout = inflater.inflate(R.layout.about_dialog, null);
                builder.setView(layout);
                builder.setPositiveButton("OK", null);
                dialog = builder.create();

                break;

            case DIALOG_QUIT_ID:
                // Create the quit confirmation dialog
                builder.setMessage(R.string.quit_question)
                        .setCancelable(false)
                        .setPositiveButton(R.string.yes, new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                AndroidTicTacToeActivity.this.finishAffinity();
                            }
                        })
                        .setNegativeButton(R.string.no, null);
                dialog = builder.create();

                break;
        }

        return dialog;
    }

    private boolean setMove(char player, int location) {

        if(mGame.setMove(player, location)){
            mBoardView.invalidate();   // Redraw the board
            return true;
        }
        return false;
    }

    // Listen for touches on the board
    private View.OnTouchListener mTouchListener = new View.OnTouchListener() {
        public boolean onTouch(View v, MotionEvent event) {

            // Determine which cell was touched
            int col = (int) event.getX() / mBoardView.getBoardCellWidth();
            int row = (int) event.getY() / mBoardView.getBoardCellHeight();
            int pos = row * 3 + col;

            if (mTurn == TicTacToeGame.HUMAN_PLAYER)
            if (!mGameOver && setMove(TicTacToeGame.HUMAN_PLAYER, pos))	{

                changeTurn(); // Change turn to Android

                if(mSoundTurnOn) {
                    try {
                        mHumanMediaPlayer.start();
                    } catch (Exception e) {}
                }

                // If no winner yet, let the computer make a move
                int winner = mGame.checkForWinner();
                if (winner == 0) {
                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        public void run() {

                            setMove(TicTacToeGame.COMPUTER_PLAYER, mGame.getComputerMove());
                            mBoardView.invalidate();   // Redraw the board
                            changeTurn(); // Change turn to Human

                            if(mSoundTurnOn) {
                                try {
                                    mComputerMediaPlayer.start();
                                } catch (Exception e) {}
                            }

                            int winner = mGame.checkForWinner();
                            //if not winner yet
                            if (winner == 0) {
                                //mTurn = TicTacToeGame.HUMAN_PLAYER;
                                mInfoTextView.setText(R.string.empty);
                            }else{
                                endGame(winner);
                            }

                        }
                    }, 800);

                }else{
                    endGame(winner);
                }

            }

            // So we aren't notified of continued events when finger is moved
            return false;
        }
    };

    private void changeTurn(){
        if(mTurn == TicTacToeGame.HUMAN_PLAYER){
            // Human has the current turn so change
            mTurn = TicTacToeGame.COMPUTER_PLAYER;
        }else{
            // Android has the current turn so change
            mTurn = TicTacToeGame.HUMAN_PLAYER;
        }
    }

    private void endGame(int winner) {
        if (winner == 0) {
            mInfoTextView.setText(R.string.empty);
        }else if (winner == 1) {
            mInfoTextView.setText(R.string.result_tie);
            mInfoTextView.setTextColor(Color.rgb(200, 200, 200));
            tieCount++;
        }else if (winner == 2) {
            mInfoTextView.setText(R.string.result_human_wins);
            mInfoTextView.setTextColor(Color.rgb(250, 250, 250));
            humanWonCount++;
            if(mSoundTurnOn) {
                try {
                    mWinMediaPlayer.start();
                } catch (Exception e) {}
            }
        }else {
            mInfoTextView.setText(R.string.result_computer_wins);
            mInfoTextView.setTextColor(Color.rgb(200, 0, 0));
            androidWonCount++;
            if(mSoundTurnOn) {
                try {
                    mWinMediaPlayer.start();
                } catch (Exception e) {}
            }
        }

        mGameOver = true;
        setResults();

    }

}
