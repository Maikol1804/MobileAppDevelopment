package com.bonilla.maikol.reto9;

import android.content.pm.PackageManager;
import android.location.Location;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.FragmentActivity;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GoogleApiAvailability;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.tasks.OnSuccessListener;

public class MapsActivity extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap;
    private double mLatitude = 0;
    private double mLongitude = 0;
    private Button buttonSearch;
    private EditText editTextPointInterest;
    private EditText editTextRadius;
    private FusedLocationProviderClient mFusedLocationClient;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);

        //show error dialog if GoolglePlayServices not available
        if (!checkPlayServices()) {
            finish();
        }

        buttonSearch = findViewById(R.id.btnSearch);
        editTextRadius = findViewById(R.id.editTextRadius);
        editTextPointInterest = findViewById(R.id.editTextPointInterest);

        buttonSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                query(editTextPointInterest.getText().toString(), editTextRadius.getText().toString());
            }
        });

        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);

    }

    private boolean checkPlayServices() {
        GoogleApiAvailability googleAPI = GoogleApiAvailability.getInstance();
        int result = googleAPI.isGooglePlayServicesAvailable(this);
        if(result != ConnectionResult.SUCCESS) {
            if(googleAPI.isUserResolvableError(result)) {
                googleAPI.getErrorDialog(this, result, 9000).show();
            }

            return false;
        }

        return true;
    }

    private void query(String pointInterest, String radius){

        try{

            int nearRadius = Integer.parseInt(radius);
            String API_SERVER_KEY = "AIzaSyDQpJfQ2BaD8XC8LNonCi0zbRKB9w_xQuA";

            StringBuilder googlePlacesUrl = new StringBuilder("https://maps.googleapis.com/maps/api/place/nearbysearch/json?");
            googlePlacesUrl.append("location=" + mLatitude + "," + mLongitude);
            googlePlacesUrl.append("&radius=" + nearRadius);
            googlePlacesUrl.append("&types=" + pointInterest);
            googlePlacesUrl.append("&key=" + API_SERVER_KEY);

            GooglePlacesReadTask googlePlacesReadTask = new GooglePlacesReadTask();
            Object[] toPass = new Object[2];
            toPass[0] = mMap;
            toPass[1] = googlePlacesUrl.toString();
            //toPass[1] = "https://maps.googleapis.com/maps/api/place/nearbysearch/json?location=-33.8670522,151.1957362&radius=500&type=restaurant&keyword=cruise&key=AIzaSyDQpJfQ2BaD8XC8LNonCi0zbRKB9w_xQuA";
            googlePlacesReadTask.execute(toPass);

        }catch (Exception e){
            Toast.makeText(MapsActivity.this, "Invalid radius", Toast.LENGTH_LONG).show();
        }


    }

    @Override
    public void onMapReady(final GoogleMap googleMap) {

        if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{android.Manifest.permission.ACCESS_FINE_LOCATION}, 0);
        }

        mFusedLocationClient = LocationServices.getFusedLocationProviderClient(this);

        mFusedLocationClient.getLastLocation()
                .addOnSuccessListener(this, new OnSuccessListener<Location>() {
                    @Override
                    public void onSuccess(Location location) {
                        // Got last known location. In some rare situations this can be null.
                        if (location != null) {

                            if (ContextCompat.checkSelfPermission(MapsActivity.this, android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                                ActivityCompat.requestPermissions(MapsActivity.this, new String[]{android.Manifest.permission.ACCESS_FINE_LOCATION}, 0);
                            }

                            mMap = googleMap;
                            mLatitude = location.getLatitude();
                            mLongitude = location.getLongitude();
                            LatLng sydney = new LatLng(mLatitude, mLongitude);
                            mMap.moveCamera(CameraUpdateFactory.newLatLng(sydney));
                            mMap.setMyLocationEnabled(true);
                            mMap.animateCamera(CameraUpdateFactory.zoomTo(15));

                        }
                    }
                });


    }
}
